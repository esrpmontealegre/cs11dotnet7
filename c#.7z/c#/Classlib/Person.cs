﻿using Class.Shared;

namespace Class.Shared
{
    public class Person:object
    {
        public string? Name { get; set; }
        public DateTime Birthday { get; set; }

        public void ConsoleWrite() 
        {
            WriteLine($"{Name} was born on: {Birthday:dddd}");
        }

        public int MethodIWannaCall(string input)
        {
            return input.Length;
        }

        //delegate field
        public EventHandler? ShoutOut;

        //data field
        public int angerLevel;

        //method
        public void Kalabet()
        {
            angerLevel++;
            if (angerLevel >= 3) 
            {
                //if something is listening
                if(ShoutOut != null) 
                { 
                    //then call the delegate
                    ShoutOut(this, EventArgs.Empty);
                    
                }
                //ShoutOut?.Invoke(this,EventArgs.Empty)
            }
        }

    }
    
}

