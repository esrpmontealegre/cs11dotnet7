﻿using Class.Shared;

Person jay = new () { Name = "Jay", Birthday = new (year: 1995, month: 08, day: 03) };
//jay.ConsoleWrite();

/*System.Collections.Hashtable lookUpObject = new();
lookUpObject.Add(key: 1, value: "alpha");
lookUpObject.Add(key: 2, value: "beta");
lookUpObject.Add(key: 3, value: "gamma");

lookUpObject.Add(key: jay, value: "delta");*/

//int key = 2;

//WriteLine(format:"key {0} has value: {1}", arg0: key, arg1: lookUpObject[key]);
//WriteLine(format: "key {0} has value: {1}", arg0: jay, arg1: lookUpObject[jay]);

Dictionary<int, string> lookUpIntString = new(); // allows for compiler type checking
lookUpIntString.Add(key: 1, value: "alpha");
lookUpIntString.Add(key: 2, value: "beta");
lookUpIntString.Add(key: 3, value: "gamma");
lookUpIntString.Add(key: 4, value: "delta");

int key = 3;

WriteLine(format: "key {0} has value: {1}", arg0: key, arg1: lookUpIntString[key]);

Person p1 = new();
int ans = p1.MethodIWannaCall("frog");


DelegateWithMatchingSign d = new(p1.MethodIWannaCall);
int ans2 = d("frog");

WriteLine(ans2);

jay.ShoutOut = Jay_shout;

jay.Kalabet();
jay.Kalabet();
jay.Kalabet();
jay.Kalabet();



delegate int DelegateWithMatchingSign(string s);
//object? sender 
//EventArgs e or TEventArgs e <- relevant info sa nangyayareng event
//for methods na di kailangan ng additional arg values to be passed in:
//public delegate void EventHandler(object? sender, EventArgs e);

//for methods that need additional arg values passed in as defined by generic type TEventArgs
//public delegate void EventHandler<TEventArgs>(object? sender, EventArgs e);




